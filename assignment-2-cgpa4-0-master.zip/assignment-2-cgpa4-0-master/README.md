[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/mcsQ_hon)
## Requirements for Assignment-2
1. [Read the instruction](https://github.com/STIA1123-A232/class-activity-stia1123/blob/main/Assignment-2.md)
1. [Read the Rubric](https://github.com/STIA1123-A232/class-activity-stia1123/blob/main/Rubric-Assignment-2.pdf)

## Your Info:
1. Matric Number & Name & Photo
2. School & Programme & Major & Minor

| Matric Number |     Name      |      Photo      |       School        |                        Programme                        |
|:-------------:|:--------------:|:---------------:|:-------------------:|:-------------------------------------------------------:|
| 298932 |  TANG JIE HUI  |![jie hui](https://github.com/STIA1123-A232/groupcasestudy-programmingprincesses/assets/165813301/e9244eba-a7be-4f77-8839-2fa28721e9eb) | School of Computing  |Bachelor of Science with Honours (Information Technology)|   
| 300210 | NG SHEY RU |![photo 4 PRG](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165645401/0009705f-1b25-46f8-bfb4-9d9a54a9119d) | School of Computing | Bachelor of Science with Honours (Inoformation  Technology)|
| 297860 | CHAN HUI CHUIN |![WhatsApp Image 2024-04-14 at 22 43 15](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/160419919/0deb87cc-7729-4d3b-b203-9a6ecb0478fa) | School of Computing | Bachelor of Science with Honours (Inoformation  Technology)|
| 299935 | KOK XIAO WEI |![WhatsApp Image 2024-05-09 at 15 25 26_fce7d9c2](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165992763/b1a7950f-3ac4-46ce-8a97-8fbb30269aa4) | School of Computing | Bachelor of Science with Honours (Inoformation  Technology)|
| 299980 |NISHKALLA A/P SELVA ILANGOWAN |![photo_6052866710282811199_y](https://github.com/STIA1123-A232/groupcasestudy-programmingprincesses/assets/166980977/9566d5ce-344d-4730-b150-14d3b35b8aa1)| School of Computer |Bachelor of Science with Honours (Information Technology)| 


## Result (Screenshot of the output)
![output1](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165813301/4e21633b-a278-464e-97c2-872e689c54f6)
![output2](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165813301/83cfc6a8-3a7f-488d-ab43-e994bab5248a)
![output3](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165813301/508b167e-d5b3-430d-8915-0669027c3b23)
![output4](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165813301/7013a275-0e8d-4317-ac03-9d99509c2a9b)
## UML Diagram
![UML asgm2](https://github.com/STIA1123-A232/assignment-2-cgpa4-0/assets/165813301/176a4faa-ca94-4ea1-a0c3-bbf9c84ab7c0)
## Youtube Presentation
[https://youtu.be/ozUFK0YeH40](https://youtu.be/w-mdSMOOkJE)
