package my.uum;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BillChecker extends JFrame implements ActionListener {

    private JButton b1, b2, b3, b4, b5, startButton, backButton;
    private JLabel background;
    private ImageIcon initialImage, menuImage, recordPage;
    private JPanel allRecordPage;
    private UserRecord[] records;
    private int recordCount;
    private JTextField searchField, deleteField;
    private JTextArea displayArea, resultArea, finalResultArea;
    private Calculation calculation = new Calculation();

    // Set font size
    Font smallFont = new Font("Arial", Font.BOLD, 25);
    Font bigFont = new Font("Arial", Font.BOLD, 40);
    Font buttonFont = new Font("Arial", Font.BOLD, 18);

    public BillChecker() {
        // Initialize the records list
        records = new UserRecord[10];

        // Load images
        initialImage = new ImageIcon(getClass().getResource("/Main.jpg"));
        menuImage = new ImageIcon(getClass().getResource("/Menu.jpg"));
        recordPage = new ImageIcon(getClass().getResource("/RecordPage.jpg"));

        // Resize the initial image to match the dimensions of the menu image
        initialImage = new ImageIcon(initialImage.getImage().getScaledInstance(menuImage.getIconWidth(), menuImage.getIconHeight(), Image.SCALE_DEFAULT));
        recordPage = new ImageIcon(recordPage.getImage().getScaledInstance(menuImage.getIconWidth(), menuImage.getIconHeight(), Image.SCALE_DEFAULT));

        // Set initial background
        background = new JLabel(initialImage);
        background.setBounds(0, 0, initialImage.getIconWidth(), initialImage.getIconHeight());
        add(background);

        // Create and add the "Start" button
        startButton = new JButton("Click to Start");
        startButton.setFont(bigFont);
        startButton.setBounds(430, 460, 400, 110);
        startButton.addActionListener(this);
        background.add(startButton);

        // Create the other buttons but don't add them yet
        b1 = new JButton("Add Record");
        b1.setFont(bigFont);
        b1.setBounds(400, 200, 400, 70);
        b1.addActionListener(this);

        b2 = new JButton("Display Record");
        b2.setFont(bigFont);  // Set font size for the text
        b2.setBounds(400, 300, 400, 70);
        b2.addActionListener(this);

        b3 = new JButton("Search Record");
        b3.setFont(bigFont);
        b3.setBounds(400, 400, 400, 70);
        b3.addActionListener(this);

        b4 = new JButton("Delete Record");
        b4.setFont(bigFont);
        b4.setBounds(400, 500, 400, 70);
        b4.addActionListener(this);

        b5 = new JButton("Exit");
        b5.setFont(bigFont);
        b5.setBounds(400, 600, 400, 70);
        b5.addActionListener(this);

        // Set JFrame properties
        setTitle("BILL CHECKER");
        setSize(initialImage.getIconWidth(), initialImage.getIconHeight());
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == startButton) {
            // Change the background image
            background.setIcon(menuImage);

            // Remove the "Start" button and add the other buttons
            background.remove(startButton);

            background.add(b1);
            background.add(b2);
            background.add(b3);
            background.add(b4);
            background.add(b5);

            // Resize the JFrame to fit the new background image
            setSize(menuImage.getIconWidth(), menuImage.getIconHeight());

            // Repaint and revalidate the background to show the new buttons and image
            background.revalidate();
            background.repaint();
        } else if (e.getSource() == b1) {
            showAddRecordPage();
        } else if (e.getSource() == b2) {
            showDisplayRecordPage();
        } else if (e.getSource() == b3) {
            showSearchRecordPage();
        } else if (e.getSource() == b4) {
            showDeleteRecordPage();
        } else if (e.getSource() == b5) {
            showExitPage();
            //close the application
            System.exit(0);
        }
    }

    private void showMainPage() {
        background.removeAll();
        background.setIcon(menuImage);

        background.add(b1);
        background.add(b2);
        background.add(b3);
        background.add(b4);
        background.add(b5);

        setSize(menuImage.getIconWidth(), menuImage.getIconHeight());

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }

    private void showAddRecordPage() {
        background.removeAll();
        background.setIcon(recordPage);

        allRecordPage = new JPanel();
        allRecordPage.setLayout(null);
        allRecordPage.setBounds(0, 0, recordPage.getIconWidth(), recordPage.getIconHeight());
        allRecordPage.setOpaque(false);

        JLabel recordLabel = new JLabel("Add Record");
        recordLabel.setFont(bigFont);
        recordLabel.setBounds(450, 10, 500, 300);
        allRecordPage.add(recordLabel);

        JLabel enterUserLabel = new JLabel("Enter user records to be added = ");
        enterUserLabel.setFont(smallFont);
        enterUserLabel.setBounds(300, 300, 600, 30);
        allRecordPage.add(enterUserLabel);

        JTextField enterUserField = new JTextField(20);
        enterUserField.setFont(smallFont);
        enterUserField.setBounds(800, 300, 100, 30); // Corrected position
        allRecordPage.add(enterUserField);

        JButton nextButton = new JButton("Next");
        nextButton.setFont(buttonFont);
        nextButton.setBounds(550, 450, 100, 30);
        nextButton.addActionListener(e -> {
            try {
                int addUser = Integer.parseInt(enterUserField.getText());
                showUserInputFields(addUser);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number", "Invalid", JOptionPane.ERROR_MESSAGE);
            }
        });
        allRecordPage.add(nextButton);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.setBounds(350, 450, 100, 30);
        backButton.addActionListener(e -> showMainPage());
        allRecordPage.add(backButton);

        // Add the addRecordPanel to the background
        background.add(allRecordPage);

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }


    private void showUserInputFields(int numAdded) {
        background.removeAll();

        JLabel recordLabel = new JLabel("Add Record");
        recordLabel.setFont(bigFont);
        recordLabel.setBounds(450, 10, 500, 125);
        background.add(recordLabel);

        JTextField userIdField = new JTextField(20);
        JTextField usernameField = new JTextField(20);
        JTextField unitsField = new JTextField(20);

        // Handle the record so, that can start from first record
        handleUserInputFields(1, numAdded, userIdField, usernameField, unitsField);

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }

    private void handleUserInputFields(int currentUser, int totalUsers, JTextField userIdField, JTextField usernameField, JTextField unitsField) {
        background.removeAll();

        JLabel userIdLabel = new JLabel("Input user id = ");
        userIdLabel.setFont(smallFont);
        userIdLabel.setBounds(310, 200, 330, 32);
        background.add(userIdLabel);

        userIdField.setFont(smallFont);
        userIdField.setBounds(650, 200, 400, 32);
        background.add(userIdField);

        JLabel usernameLabel = new JLabel("Input user name = ");
        usernameLabel.setFont(smallFont);
        usernameLabel.setBounds(310, 250, 330, 32);
        background.add(usernameLabel);

        usernameField.setFont(smallFont);
        usernameField.setBounds(650, 250, 400, 32);
        background.add(usernameField);

        JLabel unitsLabel = new JLabel("Number of units (kWj) = ");
        unitsLabel.setFont(smallFont);
        unitsLabel.setBounds(310, 300, 330, 32);
        background.add(unitsLabel);

        unitsField.setFont(smallFont);
        unitsField.setBounds(650, 300, 400, 32);
        background.add(unitsField);

        JButton nextButton = new JButton("Next");
        nextButton.setFont(buttonFont);
        nextButton.setBounds(380, 450, 100, 30);

        JButton backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.setBounds(580, 450, 100, 30);
        backButton.addActionListener(e -> showAddRecordPage());
        background.add(backButton);

        if (currentUser == totalUsers) {
            nextButton.setText("Submit");
            nextButton.addActionListener(e -> {
                if (userIdField.getText().isEmpty() || usernameField.getText().isEmpty() || unitsField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all the fields.", "Incompletely", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int userId = Integer.parseInt(userIdField.getText());
                    String username = usernameField.getText();
                    int units = Integer.parseInt(unitsField.getText());
                    double totalTariff = calculation.calculateTotalTariff(units);

                    int currentIndex = recordCount; // Use the current count as the index
                    records[currentIndex] = new UserRecord(userId, username, units, totalTariff);
                    recordCount++; // Increment the record count

                    JOptionPane.showMessageDialog(this, "Records add successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    showMainPage();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter valid numeric values.", "Invalid", JOptionPane.ERROR_MESSAGE);
                }
            });
        } else {
            nextButton.setText("Next");
            nextButton.addActionListener(e -> {
                if (userIdField.getText().isEmpty() || usernameField.getText().isEmpty() || unitsField.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all the fields.", "Incompletely", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    int userId = Integer.parseInt(userIdField.getText());
                    String username = usernameField.getText();
                    int units = Integer.parseInt(unitsField.getText());
                    double totalTariff = calculation.calculateTotalTariff(units);

                    int currentIndex = recordCount; // Use the current count as the index
                    records[currentIndex] = new UserRecord(userId, username, units, totalTariff);
                    recordCount++; // Increment the record count

                    // Clear the input place for new add record
                    userIdField.setText("");
                    usernameField.setText("");
                    unitsField.setText("");

                    handleUserInputFields(currentUser + 1, totalUsers, userIdField, usernameField, unitsField);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter valid numeric values.", "Invalid", JOptionPane.ERROR_MESSAGE);
                }
            });
        }
        background.add(nextButton);

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }

    // Display record
    private void showDisplayRecordPage() {
        background.removeAll();
        background.setIcon(recordPage);

        allRecordPage = new JPanel();
        allRecordPage.setLayout(null);
        allRecordPage.setBounds(0, 0, recordPage.getIconWidth(), recordPage.getIconHeight());
        allRecordPage.setOpaque(false);

        JLabel displayLabel = new JLabel("Display record");
        displayLabel.setFont(bigFont);
        displayLabel.setBounds(400, 45, 600, 50);
        allRecordPage.add(displayLabel);

        JButton searchButton = new JButton("Display");
        searchButton.setFont(buttonFont);
        searchButton.setBounds(350, 150, 100, 30);
        searchButton.addActionListener(e -> displayRecords());
        allRecordPage.add(searchButton);

        backButton = new JButton("Back");
        backButton.setFont(smallFont);
        backButton.setBounds(550, 150, 100, 30);
        backButton.addActionListener(e -> showMainPage());
        allRecordPage.add(backButton);

        displayArea = new JTextArea();
        displayArea.setFont(smallFont);
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(300, 200, 650, 400);
        allRecordPage.add(scrollPane);

        background.add(allRecordPage);

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }

    private void displayRecords() {
        StringBuilder displayText = new StringBuilder();
        if (records[0] == null) {
            displayArea.setText("No records found to display.");
            displayText.append("No records found to display.");
        } else {
            double totalPayment = 0.00;
            for (int i = 0; i < recordCount; i++) {
                UserRecord record = records[i];
                if (record != null) {
                    displayText.append("\nRecord " + (i + 1) + ":").append("\n");
                    displayText.append("Input user id = ").append(record.getId()).append("\n");
                    displayText.append("Input user name = ").append(record.getName()).append("\n");
                    displayText.append("Number of units (kWj) = ").append(record.getUnits()).append("\n");

                    // Calculate the bill details for the current record
                    int units = record.getUnits();
                    double totalTariff = calculation.calculateTotalTariff(units);
                    String billDetails = calculation.getBillDetails(units, totalTariff);

                    // Add to the display text
                    displayText.append(billDetails).append("\n");

                    calculation = new Calculation();
                    double amountSST = 0.00;
                    double amountKWTBB = 0.00;
                    if (record.getUnits() > 600) {
                        amountSST = calculation.SST(record.getUnits());
                        displayText.append("Total SST: RM ").append(String.format("%.2f", amountSST)).append("\n");
                    }

                    if (record.getUnits() > 300) {
                        amountKWTBB = calculation.KWTBB(totalTariff);
                        displayText.append("Total KWTBB: RM ").append(String.format("%.2f", amountKWTBB)).append("\n");
                        displayText.append("-------------------------------------------------\n");
                    }
                    totalPayment += totalTariff + amountSST + amountKWTBB;
                }
            }
            displayText.append("============================================");
            displayText.append("\nTotal electricity bill: RM ").append(String.format("%.2f", totalPayment)).append("\n");
            displayText.append("============================================\n");
        }
        displayArea.setText(displayText.toString());
    }

    // Method to show the search record page
    private void showSearchRecordPage() {
        background.removeAll();
        background.setIcon(recordPage);

        allRecordPage = new JPanel();
        allRecordPage.setLayout(null);
        allRecordPage.setBounds(0, 0, recordPage.getIconWidth(), recordPage.getIconHeight());
        allRecordPage.setOpaque(false);

        JLabel searchLabel = new JLabel("Search Record");
        searchLabel.setFont(bigFont);
        searchLabel.setBounds(400, 40, 600, 50);
        allRecordPage.add(searchLabel);

        JLabel searchIdLabel = new JLabel("Enter a user id to be searched = ");
        searchIdLabel.setFont(smallFont);
        searchIdLabel.setBounds(300, 100, 400, 30);
        allRecordPage.add(searchIdLabel);

        searchField = new JTextField(20);
        searchField.setFont(smallFont);
        searchField.setBounds(700, 100, 200, 30);
        allRecordPage.add(searchField);

        JButton searchButton = new JButton("Search");
        searchButton.setFont(buttonFont);
        searchButton.setBounds(350, 150, 100, 30);
        searchButton.addActionListener(e -> searchRecord());
        allRecordPage.add(searchButton);

        backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.setBounds(550, 150, 100, 30);
        backButton.addActionListener(e -> showMainPage());
        allRecordPage.add(backButton);

        resultArea = new JTextArea();
        resultArea.setFont(smallFont);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setBounds(300, 200, 650, 400);
        allRecordPage.add(scrollPane);

        background.add(allRecordPage);

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }

    // Search record
    private void searchRecord() {
        String searchId = searchField.getText().trim();
        boolean recordFound = false;
        StringBuilder result = new StringBuilder();

        try {
            int searchIntId = Integer.parseInt(searchId);
            for (int i = 0; i < recordCount; i++) {
                UserRecord record = records[i];
                if (record.getId() == searchIntId) {
                    int units = record.getUnits();
                    double totalBill = record.getElectricityBill();

                    result.append("Id: ").append(record.getId()).append("\n");
                    result.append("Name: ").append(record.getName()).append("\n");
                    result.append("Units: ").append(units).append("\n");
                    result.append(calculation.getBillDetails(units, totalBill)).append("\n");
                    result.append("-------------------------------------------------\n");
                    result.append("Total: RM ").append(String.format("%.2f", totalBill)).append("\n");
                    recordFound = true;
                }
            }
            if (!recordFound) {
                result.append("Sorry, the data is not found.");
            }
        } catch (NumberFormatException e) {
            result.append("Please enter a valid user ID for search.");
        }
        resultArea.setText(result.toString());
    }

    // Method to show the delete record page
    private void showDeleteRecordPage() {
        background.removeAll();
        background.setIcon(recordPage);

        allRecordPage = new JPanel();
        allRecordPage.setLayout(null);
        allRecordPage.setBounds(0, 0, recordPage.getIconWidth(), recordPage.getIconHeight());
        allRecordPage.setOpaque(false);

        JLabel deleteLabel = new JLabel("Delete Record");
        deleteLabel.setFont(bigFont);
        deleteLabel.setBounds(400, 10, 600, 50);
        allRecordPage.add(deleteLabel);

        JLabel deleteIdLabel = new JLabel("Enter user id to delete: ");
        deleteIdLabel.setFont(smallFont);
        deleteIdLabel.setBounds(300, 100, 400, 30);
        allRecordPage.add(deleteIdLabel);

        deleteField = new JTextField(20);
        deleteField.setFont(smallFont);
        deleteField.setBounds(650, 100, 200, 30);
        allRecordPage.add(deleteField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(buttonFont);
        deleteButton.setBounds(350, 150, 100, 30);
        deleteButton.addActionListener(e -> deleteRecord());
        allRecordPage.add(deleteButton);

        backButton = new JButton("Back");
        backButton.setFont(buttonFont);
        backButton.setBounds(550, 150, 100, 30);
        backButton.addActionListener(e -> showMainPage());
        allRecordPage.add(backButton);

        finalResultArea = new JTextArea();
        finalResultArea.setFont(smallFont);
        finalResultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(finalResultArea);
        scrollPane.setBounds(300, 200, 650, 400);
        allRecordPage.add(scrollPane);

        background.add(allRecordPage);

        // Revalidate and repaint the JFrame to update the UI
        background.revalidate();
        background.repaint();
    }

    // Delete record
    private void deleteRecord() {
        String deleteId = deleteField.getText().trim();
        StringBuilder finalResult = new StringBuilder();

        try {
            int deleteIntId = Integer.parseInt(deleteId);
            boolean validDelete = false;

            for (int i = 0; i < recordCount; i++) {
                UserRecord record = records[i];
                if (record != null && record.getId() == deleteIntId) {
                    validDelete = true;
                    records[i] = null; // Set delete record to null

                    // Shift the remaining records to fill the gap
                    for (int j = i + 1; j < recordCount; j++) {
                        records[j - 1] = records[j];
                    }
                    records[recordCount - 1] = null; // Clear the last element
                    recordCount--; // Decrease the record count

                    finalResult.append("The user ID ").append(deleteId).append(" has been successfully deleted from the array of objects.\n");
                    finalResult.append("===============================================================\n");

                    break;
                }
            }

            if (!validDelete) {
                finalResult.append("Sorry, unsuccessful.");
            } else {
                // Display remaining records
                for (int i = 0; i < recordCount; i++) {
                    UserRecord record = records[i];
                    if (record != null) {
                        double totalBill = record.getElectricityBill();
                        int units = record.getUnits();

                        finalResult.append("\nId: ").append(record.getId()).append("\n");
                        finalResult.append("Name: ").append(record.getName()).append("\n");
                        finalResult.append("Units: ").append(record.getUnits()).append("\n");
                        finalResult.append(calculation.getBillDetails(units, totalBill)).append("\n");
                        finalResult.append("-------------------------------------------------\n");
                        finalResult.append("Total: RM ").append(String.format("%.2f", totalBill)).append("\n");
                    }
                    // Show total electricity bill for remaining records
                    double totalPayment = 0.00;
                    if(record != null) {
                        totalPayment += record.getElectricityBill();
                    }
                    finalResult.append("============================================");
                    finalResult.append("\nTotal electricity bill: RM ").append(String.format("%.2f", totalPayment)).append("\n");
                    finalResult.append("============================================\n");
                }
            }

        } catch (NumberFormatException e) {
            finalResult.append("Please enter a valid user ID for delete.\n");
        }
        // Display the result of the delete operation
        finalResultArea.setText(finalResult.toString());
    }

    // Exit
    private void showExitPage(){
        background.removeAll();
        background.setIcon(recordPage);
        JOptionPane.showMessageDialog(this, "Exit. Thank you.");
    }
}
