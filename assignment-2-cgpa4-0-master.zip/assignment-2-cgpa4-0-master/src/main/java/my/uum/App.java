package my.uum;

public class App {
    public static void main(String[] args) {
        new BillChecker();
    }
}
