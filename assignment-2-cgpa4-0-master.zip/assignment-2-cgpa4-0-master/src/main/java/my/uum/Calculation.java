package my.uum;

public class Calculation {
    public double calculateTotalTariff(int units) {
        double total;
        if (units <= 200) {
            total = units * 0.218;
        } else if (units <= 300) {
            total = 200 * 0.218 + (units - 200) * 0.334;
        } else if (units <= 600) {
            total = 200 * 0.218 + 100 * 0.334 + (units - 300) * 0.516;
        } else if (units <= 900) {
            total = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + (units - 600) * 0.546;
        } else {
            total = 200 * 0.218 + 100 * 0.334 + 300 * 0.516 + 300 * 0.546 + (units - 900) * 0.571;
        }
        return total;
    }

    public String getBillDetails(int units, double total) {
        StringBuilder details = new StringBuilder();
        int remainUnits;

        // Calculate 1st tier tariff block
        double tier1Cost = Math.min(units, 200) * 0.218;
        details.append("1st Tier Tariff Block\n").append("200 x RM 0.218 = RM ").append(String.format("%.2f", tier1Cost));
        remainUnits = units - 200;

        // Calculate 2nd tier tariff block
        int secondTierUnits = Math.max(Math.min(units - 200, 100), 0);
        double tier2Cost = secondTierUnits * 0.334;
        details.append("\n\n2nd Tier Tariff Block\n").append(secondTierUnits).append(" x RM 0.334 = RM ").append(String.format("%.2f", tier2Cost));
        remainUnits -= secondTierUnits;

        // Calculate 3rd tier tariff block
        int thirdTierUnits = Math.max(Math.min(units - 300, 300), 0);
        double tier3Cost = thirdTierUnits * 0.516;
        details.append("\n\n3rd Tier Tariff Block\n").append(thirdTierUnits).append(" x RM 0.516 = RM ").append(String.format("%.2f", tier3Cost));
        remainUnits -= thirdTierUnits;

        // Calculate 4th tier tariff block
        int fourthTierUnits = Math.max(Math.min(units - 600, 300), 0);
        double tier4Cost = fourthTierUnits * 0.546;
        details.append("\n\n4th Tier Tariff Block\n").append(fourthTierUnits).append(" x RM 0.546 = RM ").append(String.format("%.2f", tier4Cost));
        remainUnits -= fourthTierUnits;

        // Calculate 5th tier tariff block
        double tier5Cost = Math.max(remainUnits,0) * 0.571;
        details.append("\n\n5th Tier Tariff Block\n").append(Math.max(remainUnits,0)).append(" x RM 0.571 = RM ").append(String.format("%.2f", tier5Cost));
        details.append("\n\nTotal Tariff: RM ").append(String.format("%.2f", total));
        return details.toString();
    }

    public double SST(int units) {
        double amountSST;
        double price4thTier = Math.min(units - 600, 300) * 0.546;
        double price5thTier = Math.max(units - 900, 0) * 0.571;
        double totalPrice = price4thTier + price5thTier;
        double rateSST = 0.06;
        
        amountSST = totalPrice * rateSST;
        return amountSST;
    }

    public double KWTBB(double total) {
        double rate = 0.016;
        double amountKWTBB;

        amountKWTBB = rate * total;
        return amountKWTBB;
    }
}
