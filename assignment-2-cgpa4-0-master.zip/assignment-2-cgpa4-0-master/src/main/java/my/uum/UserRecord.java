package my.uum;

public class UserRecord {
    private final int id;
    private final String name;
    private final int units;
    private final double electricityBill;

    // Constructor
    public UserRecord(int id, String name, int units, double electricityBill){
        this.id = id;
        this.name = name;
        this.units = units;
        this.electricityBill= electricityBill;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }

    public int getUnits() {
        return units;
    }

    public double getElectricityBill() {
        return electricityBill;
    }

    @Override
    public String toString() {
        return "User ID: " + id + ", Username: " + name + ", Units: " + units + ", Electricity Bill: RM " + electricityBill;
    }
}
